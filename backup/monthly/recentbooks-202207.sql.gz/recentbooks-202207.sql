--
-- PostgreSQL database dump
--

-- Dumped from database version 14.1 (Debian 14.1-1.pgdg110+1)
-- Dumped by pg_dump version 14.0 (Debian 14.0-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: book_genres; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.book_genres (
    "booksId" integer NOT NULL,
    "genresId" integer NOT NULL
);


ALTER TABLE public.book_genres OWNER TO postgres;

--
-- Name: book_views; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.book_views (
    id integer NOT NULL,
    views integer NOT NULL,
    created_at timestamp without time zone DEFAULT ('now'::text)::timestamp(6) with time zone NOT NULL,
    "bookId" integer
);


ALTER TABLE public.book_views OWNER TO postgres;

--
-- Name: book_views_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.book_views_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.book_views_id_seq OWNER TO postgres;

--
-- Name: book_views_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.book_views_id_seq OWNED BY public.book_views.id;


--
-- Name: books; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.books (
    id integer NOT NULL,
    title character varying NOT NULL,
    description character varying NOT NULL,
    image character varying DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT ('now'::text)::timestamp(6) with time zone NOT NULL,
    "userId" integer
);


ALTER TABLE public.books OWNER TO postgres;

--
-- Name: books_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.books_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.books_id_seq OWNER TO postgres;

--
-- Name: books_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.books_id_seq OWNED BY public.books.id;


--
-- Name: genres; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.genres (
    id integer NOT NULL,
    title character varying NOT NULL
);


ALTER TABLE public.genres OWNER TO postgres;

--
-- Name: genres_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.genres_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.genres_id_seq OWNER TO postgres;

--
-- Name: genres_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.genres_id_seq OWNED BY public.genres.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    value character varying NOT NULL,
    description character varying NOT NULL
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: user_favorite_books; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_favorite_books (
    "usersId" integer NOT NULL,
    "booksId" integer NOT NULL
);


ALTER TABLE public.user_favorite_books OWNER TO postgres;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_roles (
    "usersId" integer NOT NULL,
    "rolesId" integer NOT NULL
);


ALTER TABLE public.user_roles OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying NOT NULL,
    password character varying NOT NULL,
    banned boolean DEFAULT false NOT NULL,
    "banReason" character varying
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: book_views id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book_views ALTER COLUMN id SET DEFAULT nextval('public.book_views_id_seq'::regclass);


--
-- Name: books id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.books ALTER COLUMN id SET DEFAULT nextval('public.books_id_seq'::regclass);


--
-- Name: genres id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.genres ALTER COLUMN id SET DEFAULT nextval('public.genres_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: book_genres; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.book_genres ("booksId", "genresId") FROM stdin;
1	2
1	5
1	6
2	1
2	2
2	14
3	2
4	17
4	5
4	6
5	9
5	6
6	2
7	9
7	17
7	2
8	1
8	2
9	20
9	22
9	19
9	16
9	14
9	12
9	7
9	21
9	3
\.


--
-- Data for Name: book_views; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.book_views (id, views, created_at, "bookId") FROM stdin;
1	1	2022-01-02 18:29:02.048909	8
2	1	2022-01-02 18:29:02.048909	1
3	1	2022-01-02 18:29:02.048909	2
4	1	2022-01-02 18:29:02.048909	3
5	1	2022-01-02 18:29:02.048909	4
6	1	2022-01-02 18:29:02.048909	5
7	1	2022-01-02 18:29:02.048909	6
8	1	2022-01-02 18:29:02.048909	7
9	1	2022-01-02 18:30:02.003319	1
10	1	2022-01-02 18:30:02.003319	3
11	1	2022-01-02 18:30:02.003319	6
12	1	2022-01-02 18:32:02.095993	6
13	1	2022-01-02 18:33:02.006652	6
14	1	2022-01-02 18:33:02.006652	1
15	1	2022-01-02 18:33:02.006652	2
16	1	2022-01-02 18:34:02.047845	1
17	1	2022-01-02 18:37:02.0424	1
18	1	2022-01-02 18:40:02.080014	4
19	1	2022-01-02 18:41:02.007109	4
20	1	2022-01-02 18:42:02.065976	3
21	1	2022-07-06 20:25:02.035873	8
22	1	2022-07-06 20:28:02.005625	8
23	1	2022-07-06 20:28:02.005625	7
24	1	2022-07-06 20:28:02.005625	1
25	1	2022-07-06 20:29:02.06134	6
26	1	2022-07-06 20:30:02.088693	6
27	1	2022-07-06 20:33:02.004998	9
28	1	2022-07-06 20:44:02.063744	6
29	1	2022-07-06 20:44:02.063744	8
30	1	2022-07-06 20:44:02.063744	1
31	1	2022-07-06 20:45:02.037687	6
\.


--
-- Data for Name: books; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.books (id, title, description, image, created_at, "userId") FROM stdin;
1	Напряжение	В этом мире слово способно начать войну. Оно же остановит кровопролитие, будет гарантом мира и крепкого союза. Таковы правила: слишком много силы в крови одаренных, чтобы лжецам позволили существовать. Однако ложь все равно будет жить, свивая гнездо в сердцах самых честных и благородных, обволакивая страшные преступления красивыми словами, превращая подлость в великий подвиг.\nБудет предан забвению собственный сын, забыт и вычеркнут из родовой записи - ради великой цели, во имя исполнения пророчества. Княжеский род закроет на это глаза и разделит вину - плата достойна награды.\nНо у наследника именитых властителей, выкинутого в приют заштатного городка, найдется своя точка зрения	aeb3f397-ec0d-47a5-a1b6-2bef028b6c70.jpg	2022-01-02 18:03:11.112456	1
2	Варлорд. Темный пакт	Удивительно знакомый и в то же время чужой мир. Мир, где не было Второй мировой, и где в 2020 году высокотехнологичные армии корпораций спорят за мировое господство с владеющими магией аристократами.\nТам ему было тридцать пять. Здесь нет и пятнадцати, зато проблем на все сто - ненависть неожиданных родственников, перечеркнутый бастардной перевязью герб, презрение окружающих и запретный дар, применение которого грозит смертной казнью. Еще и в школу надо идти.	038c74d7-5321-477d-a01c-f99836aa6654.jpg	2022-01-02 18:10:38.351735	1
3	Алхимик	Герой сбегает из умирающего мира, желая прожить обычную, спокойную жизнь. Но получится ли у него это?\n\nВ прошлом мире хватало угроз. Но и новому есть, чем неприятно удивить. Герою предстоит разобраться, куда он попал, а потом найти, что противопоставить новым вызовам.	246294b2-f190-44ea-ae76-d7dd8b9d4aac.jpg	2022-01-02 18:11:42.934204	1
4	"Первый" Том 5 Цикл "1"	Оборонять труднее, чем захватить.	7ec3d3e4-0e75-4a60-8539-b18d98e8140f.jpg	2022-01-02 18:16:49.260976	1
5	Вечный Данж I	Эдик возможно и не считался плохим парнем при жизни, однако его циничные взгляды и некоторые поступки отнюдь не обрадовали высшую сущность, к которой случайно занесло его душу после смерти. И хотя он идет герою навстречу, давая сильный козырь в новом мире, без ложки дегтя тут обойтись не могло.\nПодземелье тем временем живет своей жизнью, дарит подарки, а также создает проблемы и неприятности, в которые герой волей-неволей вынужден окунаться. Пока он только в начале пути - незначительная пешка, которая мало кому интересна. Но чем дальше, тем глубже он будет погружаться в смертельные игры сильных мира сего. Будет ли он спасителем местных жителей, героем, отважным борцом со злом и рабством или же руководствоваться исключительно своими меркантильными интересами - решать только ему.	7377e3f4-9ba3-4bf6-9df8-3a1a7ab0ae05.jpg	2022-01-02 18:19:11.914349	1
6	Клан Медведя #1: Медвежонок	Смерть для верховного мага всегда была лишь мелким недоразумением — после седьмой реинкарнации начинаешь по-другому относиться к этому процессу. Так, незначительная задержка в планах. Однако он забыл главное — когда планы мешают более сильным существам, за это следует наказание. Очередная смерть не принесла облегчения — его сослали в другой мир, в чужое тело, но самое страшное — ему оставили память только последнего перерождения. Всё, что маг знал или чему учился раньше, оказалось недоступно. В таких непростых обстоятельствах остаётся сделать выбор — либо выгрызать зубами место под солнцем, либо сложить лапки и сдаться. Лег Ондо не привык отступать — в клане Бурого Медведя отродясь трусов не водилось. Если бороться, то до конца. Если сражаться, то до последней капли крови. Главное — разобраться с правилами нового мира, его особенностями и понять, каким образом здесь действует магия. И тогда никто не скажет, что младший из Медведей недостоин места в этом мире!	9aae0c39-363a-413f-9567-433629fa6f46.jpg	2022-01-02 18:20:45.405744	1
7	Темный инквизитор	Я просто хотел немного отдохнуть и отвлечься от реальности, но все пошло не так уже с самого начала. Сразу начались непонятные сбои с капсулой, потом я чисто случайно оказываюсь на темной стороне сил, хотя это только цветочки по сравнению с тем, что мне пришлось пережить дальше. Мой бог-покровитель считает меня послушной марионеткой, которая выполнит любой его приказ.\nУ меня есть только один шанс вернуть самого себя – убить бога, хотя не зря говорят, что из любой ситуации есть два выхода, вдруг мне удастся найти третий?	0f0facee-a6df-4dc2-8fdc-e13369b8cb29.jpg	2022-01-02 18:22:08.36955	1
8	Книга одиннадцатая - Охота на маску	Родовые земли в Малайзии получены. Клан Тоётоми принуждён к миру. Клан Хейг уничтожен. Род Мейкшифт уничтожен. Богатства, власти и силы не бывает много, но у Рода Аматэру их достаточно. Осталось сходить к Императору и получить право на создание клана. Ну а Древний, спрятавшийся под неизвестной маской - это уже мелочи.	82ffc5f3-6a2d-47d6-bddf-3745ec6fdae4.jpg	2022-01-02 18:26:45.837624	1
9	Идут как-то два рейпера	Один в кепке\r\nВторой... читать дальше	726ac1a2-f2fc-43ef-b1ff-0feb2d5bf243.jpg	2022-07-06 20:32:36.10244	1
\.


--
-- Data for Name: genres; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.genres (id, title) FROM stdin;
1	Фантастика
2	Фэнтэзи
3	Современная проза
4	Мистика
5	Приключения
6	Юмор
7	Поэзия
8	Ужасы
9	ЛитРПГ
10	Фанфик
11	Попаданцы
12	Триллер
13	Разное
14	Боевик
15	Детектив
16	Историческая проза
17	РеалРПГ
18	Любовные романы
19	Эротика
20	Политический роман
21	Развитие личности
22	Психология
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, value, description) FROM stdin;
1	USER	Default user
2	ADMIN	Administrator
\.


--
-- Data for Name: user_favorite_books; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_favorite_books ("usersId", "booksId") FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_roles ("usersId", "rolesId") FROM stdin;
1	1
1	2
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, password, banned, "banReason") FROM stdin;
1	user@gmail.com	$2a$05$2ucacqr0QcEtoOdBO0bBUuc64oLPXOqx6I2AGOLtAyb/9zX6ynJOy	f	\N
\.


--
-- Name: book_views_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.book_views_id_seq', 31, true);


--
-- Name: books_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.books_id_seq', 9, true);


--
-- Name: genres_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.genres_id_seq', 22, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_id_seq', 2, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: user_roles PK_38ffcfb865fc628fa337d9a0d4f; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT "PK_38ffcfb865fc628fa337d9a0d4f" PRIMARY KEY ("usersId", "rolesId");


--
-- Name: book_genres PK_511ed2a2ca5c2f51e63c3f11569; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book_genres
    ADD CONSTRAINT "PK_511ed2a2ca5c2f51e63c3f11569" PRIMARY KEY ("booksId", "genresId");


--
-- Name: genres PK_80ecd718f0f00dde5d77a9be842; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.genres
    ADD CONSTRAINT "PK_80ecd718f0f00dde5d77a9be842" PRIMARY KEY (id);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: roles PK_c1433d71a4838793a49dcad46ab; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT "PK_c1433d71a4838793a49dcad46ab" PRIMARY KEY (id);


--
-- Name: book_views PK_c7f6ebc5d1eefecb36a69d80d90; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book_views
    ADD CONSTRAINT "PK_c7f6ebc5d1eefecb36a69d80d90" PRIMARY KEY (id);


--
-- Name: user_favorite_books PK_e35ed380b23f56878f1e9bc14bd; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_favorite_books
    ADD CONSTRAINT "PK_e35ed380b23f56878f1e9bc14bd" PRIMARY KEY ("usersId", "booksId");


--
-- Name: books PK_f3f2f25a099d24e12545b70b022; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT "PK_f3f2f25a099d24e12545b70b022" PRIMARY KEY (id);


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: genres UQ_b37dce0f06a1eeb5195e5045175; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.genres
    ADD CONSTRAINT "UQ_b37dce0f06a1eeb5195e5045175" UNIQUE (title);


--
-- Name: roles UQ_bb7d685810f5cba57e9ff6756fb; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT "UQ_bb7d685810f5cba57e9ff6756fb" UNIQUE (value);


--
-- Name: IDX_0591901c662206c65fdbdc5564; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_0591901c662206c65fdbdc5564" ON public.book_genres USING btree ("booksId");


--
-- Name: IDX_13380e7efec83468d73fc37938; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_13380e7efec83468d73fc37938" ON public.user_roles USING btree ("rolesId");


--
-- Name: IDX_2a4697e86ea277b041ce458d3b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_2a4697e86ea277b041ce458d3b" ON public.user_favorite_books USING btree ("usersId");


--
-- Name: IDX_99b019339f52c63ae615358738; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_99b019339f52c63ae615358738" ON public.user_roles USING btree ("usersId");


--
-- Name: IDX_a08de8b1a0d01fff62652421a6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_a08de8b1a0d01fff62652421a6" ON public.user_favorite_books USING btree ("booksId");


--
-- Name: IDX_d3b69f17a3f53a9e52c802a348; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_d3b69f17a3f53a9e52c802a348" ON public.book_genres USING btree ("genresId");


--
-- Name: book_genres FK_0591901c662206c65fdbdc55644; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book_genres
    ADD CONSTRAINT "FK_0591901c662206c65fdbdc55644" FOREIGN KEY ("booksId") REFERENCES public.books(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_roles FK_13380e7efec83468d73fc37938e; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT "FK_13380e7efec83468d73fc37938e" FOREIGN KEY ("rolesId") REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_favorite_books FK_2a4697e86ea277b041ce458d3ba; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_favorite_books
    ADD CONSTRAINT "FK_2a4697e86ea277b041ce458d3ba" FOREIGN KEY ("usersId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: book_views FK_8ba11d5bc51ac50162687dc1ec3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book_views
    ADD CONSTRAINT "FK_8ba11d5bc51ac50162687dc1ec3" FOREIGN KEY ("bookId") REFERENCES public.books(id);


--
-- Name: user_roles FK_99b019339f52c63ae6153587380; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT "FK_99b019339f52c63ae6153587380" FOREIGN KEY ("usersId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_favorite_books FK_a08de8b1a0d01fff62652421a65; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_favorite_books
    ADD CONSTRAINT "FK_a08de8b1a0d01fff62652421a65" FOREIGN KEY ("booksId") REFERENCES public.books(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: books FK_bb8627d137a861e2d5dc8d1eb20; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT "FK_bb8627d137a861e2d5dc8d1eb20" FOREIGN KEY ("userId") REFERENCES public.users(id);


--
-- Name: book_genres FK_d3b69f17a3f53a9e52c802a348d; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book_genres
    ADD CONSTRAINT "FK_d3b69f17a3f53a9e52c802a348d" FOREIGN KEY ("genresId") REFERENCES public.genres(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

